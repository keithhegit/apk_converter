import React, { useState, useEffect } from 'react'
import './App.css'

function App() {
  const [count, setCount] = useState(0)
  const [time, setTime] = useState(new Date())
  const [device, setDevice] = useState('检测中...')

  useEffect(() => {
    // 检测设备
    const ua = navigator.userAgent
    let deviceType = 'Desktop'
    
    if (/Android/i.test(ua)) {
      deviceType = 'Android'
    } else if (/iPhone|iPad|iPod/i.test(ua)) {
      deviceType = 'iOS'
    }
    
    setDevice(deviceType)

    // 更新时间
    const timer = setInterval(() => {
      setTime(new Date())
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  return (
    <div className="app">
      <div className="container">
        <h1>🚀 React Vibe App</h1>
        <p className="subtitle">使用 React + Vite 构建</p>
        
        <div className="counter-section">
          <div className="counter">{count}</div>
          <button 
            className="button" 
            onClick={() => setCount(count + 1)}
          >
            点击计数 +1
          </button>
          <button 
            className="button secondary" 
            onClick={() => setCount(0)}
          >
            重置
          </button>
        </div>

        <div className="info-card">
          <div className="info-item">
            <span className="icon">📱</span>
            <strong>设备:</strong> {device}
          </div>
          <div className="info-item">
            <span className="icon">⏰</span>
            <strong>时间:</strong> {time.toLocaleTimeString('zh-CN')}
          </div>
          <div className="info-item">
            <span className="icon">⚛️</span>
            <strong>框架:</strong> React {React.version}
          </div>
        </div>

        <div className="features">
          <div className="feature">
            <div className="feature-icon">⚡</div>
            <div className="feature-title">快速构建</div>
            <div className="feature-desc">使用 Vite 实现极速热更新</div>
          </div>
          <div className="feature">
            <div className="feature-icon">📦</div>
            <div className="feature-title">一键打包</div>
            <div className="feature-desc">轻松打包成 Android APK</div>
          </div>
          <div className="feature">
            <div className="feature-icon">🎨</div>
            <div className="feature-title">现代设计</div>
            <div className="feature-desc">精美的渐变和动画效果</div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default App
