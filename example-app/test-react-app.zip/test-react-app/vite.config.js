import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import legacy from '@vitejs/plugin-legacy'

export default defineConfig({
  plugins: [
    react(),
    legacy({
      targets: ['defaults', 'not IE 11', 'chrome >= 52', 'android >= 5'],
      // 生成传统版本，不需要 ES module
      renderLegacyChunks: true,
      // 为现代浏览器也生成非 module 版本
      modernPolyfills: true,
    })
  ],
  base: './',
  build: {
    target: 'es2015',
    cssTarget: 'chrome61',
  }
})
